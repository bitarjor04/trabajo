import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

class Acuerdos extends Documento {
    private String Nombre_1;
    private String Nombre_2;
    private String fecha;
    private String vigencia;
    Scanner dat = new Scanner(System.in);
    Scanner secondPerson = new Scanner(System.in);
    Scanner ac = new Scanner(System.in);

    public Acuerdos() {

    }

    public Acuerdos(String nombre_Documento, String formato_Doc, boolean privado, String fecha, String nombre_1,
                    String nombre_2, String fecha2, String vigencia) {
        super(nombre_Documento, formato_Doc, privado);
        Nombre_1 = nombre_1;
        Nombre_2 = nombre_2;
        fecha = fecha2;
        this.vigencia = vigencia;
    }

    public String getNombre_1() {
        return Nombre_1;
    }

    public void setNombre_1(String nombre_1) {
        Nombre_1 = nombre_1;
    }

    public String getNombre_2() {
        return Nombre_2;
    }

    public void setNombre_2(String nombre_2) {
        Nombre_2 = nombre_2;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getVigencia() {
        return vigencia;
    }

    public void setVigencia(String vigencia) {
        this.vigencia = vigencia;
    }

    public String Datos() {

        System.out.println("DATOS NECESARIOS AL ACUERDO:");

        System.out.print("Nombre y apellidos: ");
        Nombre_1 = dat.nextLine();
        System.out.print("Cedula: ");
        int cedula1 = dat.nextInt();

        System.out.print("Nombre y apellido: ");
        String nameSecondPerson = secondPerson.nextLine();


        Nombre_2 = nameSecondPerson;
        System.out.print("Cedula: ");
        int cedula2 = secondPerson.nextInt();

        LocalDate echa = LocalDate.now();

        System.out.println("vigencia: DD/MM/AAAA");
        vigencia = ac.nextLine();

        if (vigencia.length() == 8) {
            String dia = vigencia.substring(0, 2);
            String mes = vigencia.substring(2, 4);
            String anio = vigencia.substring(4, 8);

            vigencia =  dia +"/" +mes  +"/"+ anio;
        }

        System.out.println("digite el acuerdo que sea llevar a cabo");
        String acuerd = ac.nextLine();

       return "Nombre: " + Nombre_1 + "              CC: " + cedula1 + "\n" +
                "Nombre: " + Nombre_2 + "              CC: " + cedula2 + "\n" +
                "Fecha: " + echa + "              Vigencia: " + vigencia + "\n" + acuerd;


    }
}
//Documento documento = new Documento();