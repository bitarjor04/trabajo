import java.io.*;
import java.time.LocalDate;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Documento {

public String nombre_Documento;
public String Formato_Doc;
public String privado;
public String fecha;
Scanner sca=new Scanner(System.in);


public Documento(){

}
// creamos el metodo contructor para inicializar los atributos.
public Documento(String nombre_Documento, String formato_Doc, boolean privado)throws IllegalArgumentException {
    //---------------------------------------------------------------------
    // aqui tenemos la implementacion de expresiones regulares el cual tiene como proposito 
    //tener en cuenta que el nombre del documento tenga que su primera letra sea mayuscula y que al finalizar sea con un guion bajo


    this.nombre_Documento = nombre_Documento;
    Formato_Doc = formato_Doc;
    privado = privado;

}
//--------------------------------------------setter y getter ----------------------------------------------------------------------------
public String getNombre_Documento() {
    return nombre_Documento;
}
public void setNombre_Documento(String nombre_Documento) {
   this.nombre_Documento = nombre_Documento;
}
public String getFormato_Doc() {
    return Formato_Doc;
}
public void setFormato_Doc(String formato_Doc) {
    Formato_Doc = formato_Doc;
}


public String getPrivado() {
    return privado;
}
public void setPrivado(String privado) {
    this.privado = privado;
}
//---------------------------------------------------------------------------------------------------------------------------
// metodo para crear documentos
public void crear() throws IOException{
    Acuerdos acuerdos=new Acuerdos();

    System.out.println("ingrese el nombre del archivo: ");
    nombre_Documento=sca.nextLine();
    
    if (!Pattern.matches("[A-Z].*_", nombre_Documento)) {
        throw new IllegalArgumentException
                ("El nombre debe comenzar con una letra mayúscula seguida de un guion bajo.");
    }
//-------------------------------------------------------------------------------
System.out.println("tipo de formato que desee:  PDF, DOC , DOCX, HTML, HTM,  XLS , XLSX ");
    Formato_Doc=sca.nextLine();
    // aqui tenemos la implementacion de expresiones regulares el cual tiene como proposito
    // que todas las letras sean mayusculas
    if (!Pattern.matches("^(PDF|DOC|DOCX|HTML|HTM|XLS|XLSX)$", Formato_Doc)) {
        throw new IllegalArgumentException("El formato debe ser uno de los siguientes: PDF, DOC, DOCX, HTML, HTM, XLS o XLSX.");
    }
//-----------------------------------------------------------------------------------------------------------

    
               
//-------------------------------------------------------------------------------------------------------------             
int i=0;
do{
        System.out.println("privacidad: \n 1.si \n 2. no");
        privado=sca.nextLine();
        if (i == 1) {

            System.out.println("si");

        }else
                System.out.println("no");

        }

      while(i !=0);
   
    
File document= new File(nombre_Documento);
FileWriter writer = new FileWriter(document, true);

writer.write("documento: "+nombre_Documento + "\n"+
" FORMATO: "+Formato_Doc + "        "+"FECHA: "+LocalDate.now() + "        " + "PRIVADO: "+privado
        + "\n\n\n"+acuerdos.Datos());

writer.flush();
writer.close();

System.out.println("archivo creado ");

}

//metodo para actualaizar/editar

public boolean actualizar() throws IOException {
    // Pedir al usuario la ruta del documento
    System.out.println("Ingrese la ruta de su documento: ");
    String buscar = sca.nextLine();

    File doc = new File(buscar);

    // Leer y mostrar el contenido actual del archivo
    try (BufferedReader br = new BufferedReader(new FileReader(doc))) {
        String linea;
        System.out.println("Contenido actual del documento:");
        while ((linea = br.readLine()) != null) {
            System.out.println(linea);
        }
    } catch (IOException e) {
        System.err.println("Error leyendo el archivo: " + e.getMessage());
        return false;
    }

    // Pedir al usuario que ingrese nuevo contenido
    System.out.println("Ingrese el nuevo contenido para agregar al documento:");


    Acuerdos ac = new Acuerdos();

    String datos = ac.Datos();



    // Escribir el nuevo contenido en el archivo
    try (BufferedWriter escritura = new BufferedWriter(new FileWriter(doc, true))) {
        escritura.newLine();
        escritura.write(datos);
        System.out.println("Su documento ha sido actualizado.");
    } catch (IOException e) {
        System.err.println("Error escribiendo en el archivo: " + e.getMessage());
    }
return false;

  }





private Writer FileWriter(FileWriter rr) {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'FileWriter'");
    //----------------------------------------------------------------------------------------------------------
}
public void codificar(){


}
public void decodificar(){

}


}
