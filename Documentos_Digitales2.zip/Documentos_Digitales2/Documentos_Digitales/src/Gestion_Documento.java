import java.io.*;

class Gestion_Documento extends Documento {

    private int Direccion_doc;

    // metdodo contructor
    public Gestion_Documento() {
    }

    public Gestion_Documento(String nombre_Documento, String formato_Doc, boolean privado, int direccion_doc) throws IllegalArgumentException {
        super(nombre_Documento, formato_Doc, privado);
        Direccion_doc = direccion_doc;
    }

// setter y getter

    public int getDireccion_doc() {
        return Direccion_doc;

    }

    public void setDireccion_doc(int direccion_doc) {
        Direccion_doc = direccion_doc;

    }


    // creamos un metodo para organizar los documentos
    public void organizar() {

    }

    // metodo para crear los documentos
    public void agregar() throws IOException {
        crear();

    }

    // metodo para buscar los documentos
    public boolean buscar() throws NumberFormatException, IOException {
        int n;
        System.out.println("buscar docuemnto: ");
        String buscar = sca.nextLine();
        File doc = new File(buscar);
        if (doc.exists()) {
            System.out.println("docuemnto encontrado: "+buscar);

           

            // Leer y mostrar el contenido actual del archivo
            try (BufferedReader br = new BufferedReader(new FileReader(doc))) {
                String linea;
                System.out.println("Contenido actual del documento:");
                while ((linea = br.readLine()) != null) {
                    System.out.println(linea);
                }
            } catch (IOException e) {
                System.err.println("Error leyendo el archivo: " + e.getMessage());
                return false;
            }

return true;
        } else {
            System.out.println("documento no encontrado");


        }
        return false;
    }


// metodo para editar documentos

// metodos para elimar documentos 
public void eliminar(){
    System.out.println("buscar docuemnto: ");
    String buscar=sca.nextLine();
    File borrar = new File(buscar);

    if (borrar.delete())

        System.out.println("El fichero se ha sido borrado corectamente"+buscar);
    else
        System.out.println("El documento no pudó ser borrado");
}

// metodos para mostrar documentos 
public void mostrar(){
}

}

