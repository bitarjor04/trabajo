
import java.util.Scanner;

 public class App {
    public static void main(String[] args) throws Exception {
        boolean exit = false;
      while (!exit){
          Scanner entra = new Scanner(System.in);

          Documento doc = new Documento();
          Gestion_Documento arch = new Gestion_Documento();

          String opcion;
          System.out.println("  DOCUMENTOS ");
          System.out.println("  1. CREAR DOCUMENTO");
          System.out.println("  2. ACTUALIZAR DOCUMENTO");
          System.out.println("  3. ELIMINAR DOCUMENTO");
          System.out.println("  4. BUSCAR DOCUMENTOS");
          System.out.println("  5. MOSTRAR DOCUMENTO ");
          opcion = entra.nextLine();
          switch (opcion) {
              case "1":
                  doc.crear();
                  break;
              case "2":
                  doc.actualizar();
                  break;
              case "3":
                  arch.eliminar();
                  break;
              case "4":
                  arch.buscar();
                  break;
              case "5":
                  arch.mostrar();
                  break;

          }
      }

/*
        boolean exist = doc.actualizar();
        if (!exist) {
            System.out.println("No se puede modificar el Documento");
            System.out.println("Vamos a crear un nuevo Documento");
            doc.crear();
        }*/

    }}