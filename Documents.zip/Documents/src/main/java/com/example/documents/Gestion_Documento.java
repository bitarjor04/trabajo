package com.example.documents;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

class Gestion_Documento extends Documento {

    private int Direccion_doc;

    // metdodo contructor
    public Gestion_Documento() {
    }

    public Gestion_Documento(String nombre_Documento, String formato_Doc, boolean privado, int direccion_doc) throws IllegalArgumentException {
        super(nombre_Documento, formato_Doc, privado);
        Direccion_doc = direccion_doc;
    }

// setter y getter

    public int getDireccion_doc() {
        return Direccion_doc;

    }

    public void setDireccion_doc(int direccion_doc) {
        Direccion_doc = direccion_doc;

    }


    // creamos un metodo para organizar los documentos
    public void organizar() {

    }



    // metodo para buscar los documentos
    public String buscar(String search) throws NumberFormatException, IOException {
        int n;
        String buscar = search;
        File doc = new File(buscar);
        if (doc.exists()) {
            System.out.println("docuemnto encontrado: "+buscar);


            StringBuilder docString = new StringBuilder();
            // Leer y mostrar el contenido actual del archivo
            try (BufferedReader br = new BufferedReader(new FileReader(doc))) {
                String linea;
                System.out.println("Contenido actual del documento:");
                while ((linea = br.readLine()) != null) {
                   docString.append(linea).append("\n\n");
                }
            } catch (IOException e) {
                System.err.println("Error leyendo el archivo: " + e.getMessage());
                return "No se encontró el documento";
            }
return docString.toString();

        } else {
            System.out.println("documento no encontrado");


        }
        return "Error";
    }


// metodo para editar documentos

// metodos para elimar documentos 
public void eliminar(){
    System.out.println("buscar docuemnto: ");
    String buscar=sca.nextLine();
    File borrar = new File(buscar);

    if (borrar.delete())

        System.out.println("El fichero se ha sido borrado corectamente"+buscar);
    else
        System.out.println("El documento no pudó ser borrado");
}

// metodos para mostrar documentos 
public void mostrar(){

}

}

