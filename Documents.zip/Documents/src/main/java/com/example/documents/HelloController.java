package com.example.documents;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;
import java.time.LocalDate;

public class HelloController {
    Documento doc = new Documento();
    Gestion_Documento arch = new Gestion_Documento();

    @FXML
    private Label welcomeText;


    @FXML
    private TextField searchInput;

    @FXML
    private TextField fileName;

    @FXML
    private ComboBox for_doc;

    @FXML
    private ComboBox priv_doc;
    @FXML
    private TextField nombre1;
    @FXML
    private TextField Cedula;
    @FXML
    private TextField nombre2;
    @FXML
    private TextField  cedula_2;
    @FXML
    private DatePicker vigen;
    @FXML
    private TextArea acuer;


    @FXML
    protected void onHelloButtonClick() throws IOException {

        String name = fileName.getText();
        String  ford= (String) for_doc.getValue();
        String priv= (String) priv_doc.getValue();
        String person1= nombre1.getText();
        String ced1= Cedula.getText();
        String person2= nombre2.getText();
        String ced2= cedula_2.getText();
        LocalDate vig= vigen.getValue();
        String a = acuer.getText();
     doc.crear(name,ford,priv, person1, Integer.parseInt(ced1), person2,Integer.parseInt(ced2),vig.toString(),a);
        welcomeText.setText( arch.buscar(name));
    }

    @FXML
    public void initialize() {
        // Initialize ComboBox with options
        for_doc.getItems().addAll("PDF", "DOCX", "TXT");
        priv_doc.getItems().addAll("Si", "No");
    }

    @FXML
    protected void onSearchButtonClick() throws IOException {
        String userInput = searchInput.getText();
        welcomeText.setText( arch.buscar(userInput));

    }
}