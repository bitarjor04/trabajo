package com.example.documents;

import java.time.LocalDate;
import java.util.Scanner;

class Acuerdos extends Documento {
    private String Nombre_1;
    private String Nombre_2;
    private String fecha;
    private String vigencia;
    Scanner dat = new Scanner(System.in);
    Scanner secondPerson = new Scanner(System.in);
    Scanner ac = new Scanner(System.in);

    public Acuerdos() {

    }

    public Acuerdos(String nombre_Documento, String formato_Doc, boolean privado, String fecha, String nombre_1,
                    String nombre_2, String fecha2, String vigencia) {
        super(nombre_Documento, formato_Doc, privado);
        Nombre_1 = nombre_1;
        Nombre_2 = nombre_2;
        fecha = fecha2;
        this.vigencia = vigencia;
    }

    public String getNombre_1() {
        return Nombre_1;
    }

    public void setNombre_1(String nombre_1) {
        Nombre_1 = nombre_1;
    }

    public String getNombre_2() {
        return Nombre_2;
    }

    public void setNombre_2(String nombre_2) {
        Nombre_2 = nombre_2;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getVigencia() {
        return vigencia;
    }

    public void setVigencia(String vigencia) {
        this.vigencia = vigencia;
    }

    public String Datos(String nombre1,int cedul1, String nombre2,int cedula_2, String vigen,String acue) {


        Nombre_1 = nombre1;
Nombre_2 = nombre2;
vigencia = vigen;
int cedula1 = cedul1;
int cedula2=cedula_2;





        LocalDate echa = LocalDate.now();


        String acuerd = acue;

       return "Nombre: " + Nombre_1 + "              CC: " + cedula1 + "\n" +
                "Nombre: " + Nombre_2 + "              CC: " + cedula2 + "\n" +
                "Fecha: " + echa + "              Vigencia: " + vigencia + "\n" + acuerd;


    }
}
